-- SILVSGPT Database Schema
-- Run this in your Supabase SQL Editor

-- Agents Table
CREATE TABLE IF NOT EXISTS agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('online', 'offline', 'standby')),
  type TEXT NOT NULL CHECK (type IN ('local', 'cloud', 'fallback')),
  requests INTEGER DEFAULT 0,
  uptime_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Plugins Table
CREATE TABLE IF NOT EXISTS plugins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  enabled BOOLEAN DEFAULT true,
  description TEXT,
  author TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Commands History Table
CREATE TABLE IF NOT EXISTS commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  command TEXT NOT NULL,
  response TEXT,
  status TEXT NOT NULL CHECK (status IN ('success', 'error', 'pending')),
  agent_used TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- System Settings Table
CREATE TABLE IF NOT EXISTS system_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default agents
INSERT INTO agents (name, status, type, requests) VALUES
  ('LocalGPT', 'online', 'local', 0),
  ('CloudFallback', 'standby', 'cloud', 0),
  ('VoiceAgent', 'online', 'local', 0),
  ('PCControl', 'online', 'local', 0)
ON CONFLICT DO NOTHING;

-- Insert default plugins
INSERT INTO plugins (name, version, enabled, description, author) VALUES
  ('Voice Recognition', '2.1.0', true, 'Voice command processing', 'SILVSGPT Core'),
  ('PC Control', '1.5.3', true, 'System-level automation', 'SILVSGPT Core'),
  ('Code Assistant', '3.0.1', true, 'Code completion and refactoring', 'Community'),
  ('File Manager', '1.2.0', true, 'Advanced file operations', 'SILVSGPT Core'),
  ('Web Scraper', '2.0.0', false, 'Extract data from websites', 'Community')
ON CONFLICT DO NOTHING;

-- Insert default settings
INSERT INTO system_settings (key, value) VALUES
  ('api_endpoint', 'https://api.openai.com/v1'),
  ('primary_model', 'gpt-4'),
  ('fallback_model', 'gpt-3.5-turbo'),
  ('auto_failover', 'true'),
  ('voice_enabled', 'true'),
  ('voice_language', 'en'),
  ('theme', 'dark')
ON CONFLICT DO NOTHING;

-- Enable Row Level Security (RLS)
ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE plugins ENABLE ROW LEVEL SECURITY;
ALTER TABLE commands ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- Create policies (allow all for demo - restrict in production!)
CREATE POLICY "Enable read access for all users" ON agents FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON agents FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON agents FOR UPDATE USING (true);

CREATE POLICY "Enable read access for all users" ON plugins FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON plugins FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update access for all users" ON plugins FOR UPDATE USING (true);

CREATE POLICY "Enable read access for all users" ON commands FOR SELECT USING (true);
CREATE POLICY "Enable insert access for all users" ON commands FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read access for all users" ON system_settings FOR SELECT USING (true);
CREATE POLICY "Enable update access for all users" ON system_settings FOR UPDATE USING (true);
