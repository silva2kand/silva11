import { createClient } from '@supabase/supabase-js';

// Access environment variables - these are set by Figma Make when you connect to Supabase
// @ts-ignore - import.meta.env is available in Vite
const supabaseUrl = import.meta.env?.SUPABASE_URL || import.meta.env?.VITE_SUPABASE_URL || '';
// @ts-ignore
const supabaseAnonKey = import.meta.env?.SUPABASE_ANON_KEY || import.meta.env?.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('⚠️ Supabase credentials not found. Please ensure you have connected to Supabase in Figma Make.');
  console.warn('The app will still work but data will not be persisted.');
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co', 
  supabaseAnonKey || 'placeholder-key'
);

// Database types
export type Agent = {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'standby';
  type: 'local' | 'cloud' | 'fallback';
  requests: number;
  uptime_start: string;
  last_activity: string;
  created_at: string;
};

export type Plugin = {
  id: string;
  name: string;
  version: string;
  enabled: boolean;
  description: string;
  author: string;
  created_at: string;
  updated_at: string;
};

export type Command = {
  id: string;
  command: string;
  response: string;
  status: 'success' | 'error' | 'pending';
  agent_used: string;
  created_at: string;
};

export type SystemSetting = {
  id: string;
  key: string;
  value: string;
  updated_at: string;
};
