# SILVSGPT Setup Instructions

## 1. Configure Supabase

Your Supabase connection needs to be properly configured. Make sure you have:

- `SUPABASE_URL` environment variable set
- `SUPABASE_ANON_KEY` environment variable set

## 2. Create Database Tables

Go to your Supabase dashboard:

1. Navigate to the **SQL Editor**
2. Copy the entire contents of `/lib/database-setup.sql`
3. Paste and click **Run**

This will create:
- `agents` table (stores your AI agents)
- `plugins` table (stores enabled/disabled plugins)
- `commands` table (stores command history)
- `system_settings` table (stores app configuration)

Plus default data for agents, plugins, and settings.

## 3. Verify Setup

After running the SQL:

1. Go to **Table Editor** in Supabase
2. You should see 4 tables: agents, plugins, commands, system_settings
3. Check that default data was inserted

## 4. Test the App

Try these commands in SILVSGPT:
- `system status` - See all agents and plugins
- `list agents` - View all agents
- `list plugins` - View all plugins
- `help` - See available commands

## 5. Environment Variables (if needed)

If you're running this locally, create a `.env` file:

```
SUPABASE_URL=your_supabase_project_url
SUPABASE_ANON_KEY=your_supabase_anon_key
```

Get these from your Supabase project settings → API.

---

## Troubleshooting

**"Cannot read properties of undefined"**
- Make sure Supabase is properly connected in Figma Make
- Check that environment variables are set

**No data showing in dialogs**
- Run the SQL setup script in Supabase
- Check browser console for errors

**Commands not saving**
- Verify database tables exist
- Check Row Level Security policies are enabled
