import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { supabase, type Plugin } from '../lib/supabase';
import { togglePlugin } from '../lib/api';

type PluginsDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function PluginsDialog({ open, onOpenChange }: PluginsDialogProps) {
  const [plugins, setPlugins] = useState<Plugin[]>([]);

  useEffect(() => {
    if (open) {
      loadPlugins();
    }
  }, [open]);

  const loadPlugins = async () => {
    try {
      const { data, error } = await supabase
        .from('plugins')
        .select('*')
        .order('created_at', { ascending: true });
      
      if (error) {
        console.error('Error loading plugins:', error);
        return;
      }
      
      if (data) {
        setPlugins(data);
      }
    } catch (err) {
      console.error('Failed to load plugins:', err);
    }
  };

  const handleTogglePlugin = async (id: string, currentEnabled: boolean) => {
    await togglePlugin(id, !currentEnabled);
    loadPlugins();
  };

  const enabledCount = plugins.filter(p => p.enabled).length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Plugins</DialogTitle>
          <DialogDescription className="text-zinc-400">
            {enabledCount} of {plugins.length} plugins enabled
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 mt-4">
          {plugins.map((plugin) => (
            <div
              key={plugin.id}
              className="p-4 rounded-lg border border-zinc-800 bg-zinc-800/30"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white">{plugin.name}</span>
                    <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                      v{plugin.version}
                    </Badge>
                  </div>
                  <p className="text-xs text-zinc-500">{plugin.description}</p>
                </div>
                <Switch
                  checked={plugin.enabled}
                  onCheckedChange={() => handleTogglePlugin(plugin.id, plugin.enabled)}
                />
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
