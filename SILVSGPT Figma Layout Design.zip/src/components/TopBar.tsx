import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Settings, Menu } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

type TopBarProps = {
  onOpenSettings: () => void;
  onOpenAgents: () => void;
  onOpenPlugins: () => void;
};

export function TopBar({ onOpenSettings, onOpenAgents, onOpenPlugins }: TopBarProps) {
  return (
    <div className="border-b border-zinc-800 bg-zinc-900/80 backdrop-blur-sm flex-shrink-0">
      <div className="px-4 h-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-lg text-white">SILVSGPT</h1>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
            <span className="text-xs text-zinc-400">3 agents online</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={onOpenSettings}
            className="text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <Settings className="w-4 h-4" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-zinc-400 hover:text-white hover:bg-zinc-800"
              >
                <Menu className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-zinc-900 border-zinc-800">
              <DropdownMenuItem
                onClick={onOpenAgents}
                className="text-zinc-300 focus:bg-zinc-800 focus:text-white cursor-pointer"
              >
                Agents
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={onOpenPlugins}
                className="text-zinc-300 focus:bg-zinc-800 focus:text-white cursor-pointer"
              >
                Plugins
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-zinc-800" />
              <DropdownMenuItem className="text-zinc-300 focus:bg-zinc-800 focus:text-white cursor-pointer">
                Documentation
              </DropdownMenuItem>
              <DropdownMenuItem className="text-zinc-300 focus:bg-zinc-800 focus:text-white cursor-pointer">
                About
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}
