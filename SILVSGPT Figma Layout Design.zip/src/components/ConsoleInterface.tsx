import { useState, useRef, useEffect } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Send, Mic, Loader2 } from 'lucide-react';
import { processCommand } from '../lib/api';
import { supabase } from '../lib/supabase';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
};

export function ConsoleInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'SILVSGPT ready. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load command history on mount
  useEffect(() => {
    loadCommandHistory();
  }, []);

  const loadCommandHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('commands')
        .select('*')
        .order('created_at', { ascending: true })
        .limit(10);

      if (error) {
        console.error('Error loading history:', error);
        return;
      }

      if (data && data.length > 0) {
        const historicalMessages: Message[] = [];
        data.forEach((cmd) => {
          historicalMessages.push({
            id: `${cmd.id}-user`,
            role: 'user',
            content: cmd.command,
            timestamp: new Date(cmd.created_at)
          });
          if (cmd.response) {
            historicalMessages.push({
              id: `${cmd.id}-assistant`,
              role: 'assistant',
              content: cmd.response,
              timestamp: new Date(cmd.created_at)
            });
          }
        });
        setMessages([messages[0], ...historicalMessages]);
      }
    } catch (err) {
      console.error('Failed to load history:', err);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsProcessing(true);

    // Process command with AI
    const result = await processCommand(currentInput);

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: result.response,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, assistantMessage]);
    setIsProcessing(false);
  };

  const handleQuickCommand = async (cmd: string) => {
    setInput(cmd);
    // Trigger submit
    const fakeEvent = { preventDefault: () => {} } as React.FormEvent;
    await handleSubmit(fakeEvent);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-4">
          {messages.length === 1 && (
            <div className="text-center py-6">
              <h2 className="text-2xl text-white mb-2">SILVSGPT</h2>
              <p className="text-sm text-zinc-400 mb-6">Command. Chat. Create.</p>
              <div className="grid gap-2 max-w-md mx-auto">
                <button 
                  onClick={() => handleQuickCommand('system status')}
                  className="p-2.5 rounded-lg border border-zinc-800 hover:bg-zinc-900 transition-colors text-left"
                >
                  <div className="text-sm text-white">Check system status</div>
                  <div className="text-xs text-zinc-500 mt-0.5">View all agents and services</div>
                </button>
                <button 
                  onClick={() => handleQuickCommand('list plugins')}
                  className="p-2.5 rounded-lg border border-zinc-800 hover:bg-zinc-900 transition-colors text-left"
                >
                  <div className="text-sm text-white">List active plugins</div>
                  <div className="text-xs text-zinc-500 mt-0.5">See what's currently loaded</div>
                </button>
                <button 
                  onClick={() => handleQuickCommand('help')}
                  className="p-2.5 rounded-lg border border-zinc-800 hover:bg-zinc-900 transition-colors text-left"
                >
                  <div className="text-sm text-white">Show available commands</div>
                  <div className="text-xs text-zinc-500 mt-0.5">See what I can do</div>
                </button>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`mb-4 ${message.role === 'user' ? 'flex justify-end' : ''}`}
            >
              {message.role === 'assistant' ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center text-xs text-white">
                      AI
                    </div>
                    <span className="text-xs text-zinc-500">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="text-sm text-zinc-200 whitespace-pre-wrap leading-relaxed">
                    {message.content}
                  </div>
                </div>
              ) : (
                <div className="max-w-[80%]">
                  <div className="flex items-center gap-2 mb-1 justify-end">
                    <span className="text-xs text-zinc-500">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="bg-blue-600 text-white px-3 py-2 rounded-2xl inline-block text-sm">
                    {message.content}
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-zinc-800 bg-zinc-900/80 backdrop-blur-sm flex-shrink-0">
        <div className="px-4 py-3">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a command or ask a question..."
              className="flex-1 bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500 focus-visible:ring-blue-600 h-9"
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="text-zinc-400 hover:text-white hover:bg-zinc-800 h-9 w-9"
            >
              <Mic className="w-4 h-4" />
            </Button>
            <Button
              type="submit"
              disabled={!input.trim() || isProcessing}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 h-9"
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </form>
          <p className="text-xs text-zinc-500 text-center mt-1.5">
            Fast, local, voice-ready, never fails
          </p>
        </div>
      </div>
    </div>
  );
}
