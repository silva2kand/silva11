import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Play, Square, RotateCw } from 'lucide-react';
import { supabase, type Agent } from '../lib/supabase';
import { updateAgentStatus } from '../lib/api';

type AgentsDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function AgentsDialog({ open, onOpenChange }: AgentsDialogProps) {
  const [agents, setAgents] = useState<Agent[]>([]);

  useEffect(() => {
    if (open) {
      loadAgents();
    }
  }, [open]);

  const loadAgents = async () => {
    try {
      const { data, error } = await supabase
        .from('agents')
        .select('*')
        .order('created_at', { ascending: true });
      
      if (error) {
        console.error('Error loading agents:', error);
        return;
      }
      
      if (data) {
        setAgents(data);
      }
    } catch (err) {
      console.error('Failed to load agents:', err);
    }
  };

  const handleStatusChange = async (agentId: string, newStatus: 'online' | 'offline' | 'standby') => {
    await updateAgentStatus(agentId, newStatus);
    loadAgents();
  };

  const getStatusColor = (status: Agent['status']) => {
    switch (status) {
      case 'online':
        return 'bg-green-600';
      case 'offline':
        return 'bg-red-600';
      case 'standby':
        return 'bg-yellow-600';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Agents</DialogTitle>
          <DialogDescription className="text-zinc-400">
            Manage AI agents and their status
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 mt-4">
          {agents.map((agent) => (
            <div
              key={agent.name}
              className="p-4 rounded-lg border border-zinc-800 bg-zinc-800/30"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white">{agent.name}</span>
                    <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                      {agent.type}
                    </Badge>
                  </div>
                  <p className="text-xs text-zinc-500">{agent.requests} requests processed</p>
                </div>
                <Badge className={getStatusColor(agent.status)}>
                  {agent.status}
                </Badge>
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="border-zinc-700 hover:bg-zinc-700"
                  onClick={() => handleStatusChange(agent.id, 'online')}
                  disabled={agent.status === 'online'}
                >
                  <Play className="w-3 h-3 mr-1" />
                  Start
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="border-zinc-700 hover:bg-zinc-700"
                  onClick={() => handleStatusChange(agent.id, 'offline')}
                  disabled={agent.status === 'offline'}
                >
                  <Square className="w-3 h-3 mr-1" />
                  Stop
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="border-zinc-700 hover:bg-zinc-700"
                  onClick={() => handleStatusChange(agent.id, 'standby')}
                >
                  <RotateCw className="w-3 h-3 mr-1" />
                  Standby
                </Button>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
