import { useState } from 'react';
import { ConsoleInterface } from './components/ConsoleInterface';
import { TopBar } from './components/TopBar';
import { SettingsDialog } from './components/SettingsDialog';
import { AgentsDialog } from './components/AgentsDialog';
import { PluginsDialog } from './components/PluginsDialog';

export default function App() {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [agentsOpen, setAgentsOpen] = useState(false);
  const [pluginsOpen, setPluginsOpen] = useState(false);

  return (
    <div className="flex items-center justify-center min-h-screen bg-zinc-950 p-4">
      <div className="flex flex-col w-full max-w-4xl h-[680px] bg-zinc-900 rounded-xl border border-zinc-800 shadow-2xl overflow-hidden">
        <TopBar
          onOpenSettings={() => setSettingsOpen(true)}
          onOpenAgents={() => setAgentsOpen(true)}
          onOpenPlugins={() => setPluginsOpen(true)}
        />
        
        <ConsoleInterface />

        <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
        <AgentsDialog open={agentsOpen} onOpenChange={setAgentsOpen} />
        <PluginsDialog open={pluginsOpen} onOpenChange={setPluginsOpen} />
      </div>
    </div>
  );
}
