
  # SILVSGPT Figma Layout Design

  This is a code bundle for SILVSGPT Figma Layout Design. The original project is available at https://www.figma.com/design/mBpKPsOINhg9NYOAEjy2Wc/SILVSGPT-Figma-Layout-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  