import { consumeStream, convertToModelMessages, streamText, type UIMessage, tool } from "ai"
import { createOpenRouter } from "@openrouter/ai-sdk-provider"
import { z } from "zod"
import { exec } from "child_process"
import { promisify } from "util"
import os from "os"

const execAsync = promisify(exec)

export const maxDuration = 30

const tools = {
  getSystemInfo: tool({
    description: "Get information about the PC system including OS, CPU, memory, and platform details",
    parameters: z.object({}),
    execute: async () => {
      try {
        const systemInfo = {
          platform: os.platform(),
          type: os.type(),
          release: os.release(),
          arch: os.arch(),
          hostname: os.hostname(),
          cpus: os.cpus().length,
          totalMemory: `${(os.totalmem() / 1024 / 1024 / 1024).toFixed(2)} GB`,
          freeMemory: `${(os.freemem() / 1024 / 1024 / 1024).toFixed(2)} GB`,
          uptime: `${(os.uptime() / 3600).toFixed(2)} hours`,
        }
        return systemInfo
      } catch (error) {
        return { error: "Failed to get system information" }
      }
    },
  }),

  executeBashCommand: tool({
    description:
      "Execute a bash/shell command on the PC. Use this for file operations, system commands, or running programs. Be careful with destructive commands.",
    parameters: z.object({
      command: z.string().describe("The bash command to execute"),
    }),
    execute: async ({ command }) => {
      try {
        // Security: Block potentially dangerous commands
        const dangerousPatterns = [
          /rm\s+-rf\s+\//,
          /format/i,
          /del\s+\/[sf]/i,
          /shutdown/i,
          /reboot/i,
          /mkfs/i,
          /dd\s+if=/i,
        ]

        if (dangerousPatterns.some((pattern) => pattern.test(command))) {
          return { error: "Command blocked for safety reasons" }
        }

        const { stdout, stderr } = await execAsync(command, {
          timeout: 10000, // 10 second timeout
          maxBuffer: 1024 * 1024, // 1MB buffer
        })

        return {
          stdout: stdout || "Command executed successfully (no output)",
          stderr: stderr || null,
        }
      } catch (error: any) {
        return {
          error: error.message || "Failed to execute command",
          stderr: error.stderr || null,
        }
      }
    },
  }),

  listDirectory: tool({
    description: "List files and directories in a specified path",
    parameters: z.object({
      path: z.string().describe("The directory path to list (use '.' for current directory)"),
    }),
    execute: async ({ path }) => {
      try {
        const command = os.platform() === "win32" ? `dir "${path}"` : `ls -la "${path}"`
        const { stdout, stderr } = await execAsync(command, {
          timeout: 5000,
        })

        return {
          output: stdout,
          error: stderr || null,
        }
      } catch (error: any) {
        return { error: error.message || "Failed to list directory" }
      }
    },
  }),

  getCurrentDirectory: tool({
    description: "Get the current working directory path",
    parameters: z.object({}),
    execute: async () => {
      try {
        return {
          currentDirectory: process.cwd(),
          homeDirectory: os.homedir(),
        }
      } catch (error: any) {
        return { error: error.message || "Failed to get current directory" }
      }
    },
  }),

  getProcessInfo: tool({
    description: "Get information about running processes on the system",
    parameters: z.object({}),
    execute: async () => {
      try {
        const command = os.platform() === "win32" ? "tasklist" : "ps aux"
        const { stdout } = await execAsync(command, {
          timeout: 5000,
          maxBuffer: 2 * 1024 * 1024, // 2MB buffer for process list
        })

        return {
          processes: stdout.split("\n").slice(0, 20).join("\n"), // First 20 processes
          note: "Showing first 20 processes only",
        }
      } catch (error: any) {
        return { error: error.message || "Failed to get process information" }
      }
    },
  }),
}

export async function POST(req: Request) {
  try {
    const { messages }: { messages: UIMessage[] } = await req.json()
    const apiKey = req.headers.get("X-API-Key")

    if (!apiKey) {
      return Response.json({ error: "API key is required" }, { status: 401 })
    }

    const openrouter = createOpenRouter({
      apiKey: apiKey,
    })

    const prompt = convertToModelMessages(messages)

    const result = streamText({
      model: openrouter("openai/gpt-4o-mini"),
      prompt,
      tools,
      maxSteps: 5, // Allow multiple tool calls
      abortSignal: req.signal,
    })

    return result.toUIMessageStreamResponse({
      onFinish: async ({ isAborted }) => {
        if (isAborted) {
          console.log("[v0] Request aborted")
        }
      },
      consumeSseStream: consumeStream,
    })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return Response.json({ error: "Failed to process chat request" }, { status: 500 })
  }
}
