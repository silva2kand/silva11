"use client"

import type React from "react"

import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Send, Sparkles, Settings, Mic, MicOff, Volume2 } from "lucide-react"
import { useState, useRef, useEffect } from "react"
import { ApiKeyDialog } from "./api-key-dialog"

export function ChatInterface() {
  const [apiKey, setApiKey] = useState<string>("")
  const [showSettings, setShowSettings] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [inputValue, setInputValue] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const recognitionRef = useRef<any>(null)
  const synthRef = useRef<SpeechSynthesis | null>(null)

  useEffect(() => {
    const savedKey = localStorage.getItem("openrouter_api_key")
    if (savedKey) {
      setApiKey(savedKey)
    } else {
      setShowSettings(true)
    }

    if (typeof window !== "undefined") {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = false
        recognitionRef.current.interimResults = false
        recognitionRef.current.lang = "en-US"

        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript
          setInputValue(transcript)
          setIsListening(false)
        }

        recognitionRef.current.onerror = () => {
          setIsListening(false)
        }

        recognitionRef.current.onend = () => {
          setIsListening(false)
        }
      }

      synthRef.current = window.speechSynthesis
    }
  }, [])

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({
      api: "/api/chat",
      headers: {
        "X-API-Key": apiKey,
      },
    }),
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1]
      if (lastMessage.role === "assistant" && status !== "in_progress") {
        const text = lastMessage.parts
          .filter((part) => part.type === "text")
          .map((part) => (part as any).text)
          .join(" ")
        speakText(text)
      }
    }
  }, [messages, status])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputValue.trim() || status === "in_progress") return
    if (!apiKey) {
      setShowSettings(true)
      return
    }

    sendMessage({ text: inputValue })
    setInputValue("")
  }

  const handleSaveApiKey = (key: string) => {
    setApiKey(key)
    localStorage.setItem("openrouter_api_key", key)
    setShowSettings(false)
  }

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in your browser")
      return
    }

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
    } else {
      recognitionRef.current.start()
      setIsListening(true)
    }
  }

  const speakText = (text: string) => {
    if (!synthRef.current) return

    // Cancel any ongoing speech
    synthRef.current.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 1.0
    utterance.pitch = 1.0
    utterance.volume = 1.0

    utterance.onstart = () => setIsSpeaking(true)
    utterance.onend = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)

    synthRef.current.speak(utterance)
  }

  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel()
      setIsSpeaking(false)
    }
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border bg-card px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-card-foreground">AI Assistant</h1>
            <p className="text-sm text-muted-foreground">Powered by OpenRouter</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isSpeaking && (
            <Button variant="ghost" size="icon" onClick={stopSpeaking} className="text-primary">
              <Volume2 className="h-5 w-5 animate-pulse" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowSettings(true)}
            className="text-muted-foreground hover:text-foreground"
          >
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="mx-auto max-w-3xl space-y-6">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
              <h2 className="mb-2 text-2xl font-semibold text-foreground">Welcome to AI Assistant</h2>
              <p className="text-muted-foreground">
                Start a conversation with your AI assistant. Ask anything or use voice commands!
              </p>
            </div>
          )}

          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <Card
                className={`max-w-[80%] px-4 py-3 ${
                  message.role === "user" ? "bg-primary text-primary-foreground" : "bg-card text-card-foreground"
                }`}
              >
                <div className="whitespace-pre-wrap break-words text-sm leading-relaxed">
                  {message.parts.map((part, index) => {
                    if (part.type === "text") {
                      return <span key={index}>{(part as any).text}</span>
                    }
                    if (part.type === "tool-call") {
                      return (
                        <div key={index} className="my-2 rounded border border-border bg-muted p-2 text-xs">
                          <div className="font-semibold text-primary">Tool: {(part as any).toolName}</div>
                          <div className="mt-1 text-muted-foreground">
                            {JSON.stringify((part as any).args, null, 2)}
                          </div>
                        </div>
                      )
                    }
                    if (part.type === "tool-result") {
                      return (
                        <div key={index} className="my-2 rounded border border-border bg-muted p-2 text-xs">
                          <div className="font-semibold text-green-600">Result:</div>
                          <div className="mt-1 whitespace-pre-wrap font-mono">
                            {typeof (part as any).result === "string"
                              ? (part as any).result
                              : JSON.stringify((part as any).result, null, 2)}
                          </div>
                        </div>
                      )
                    }
                    return null
                  })}
                </div>
              </Card>
            </div>
          ))}

          {status === "in_progress" && (
            <div className="flex justify-start">
              <Card className="bg-card px-4 py-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="flex gap-1">
                    <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]" />
                    <div className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]" />
                    <div className="h-2 w-2 animate-bounce rounded-full bg-primary" />
                  </div>
                  <span>Thinking...</span>
                </div>
              </Card>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-border bg-card px-4 py-4">
        <form onSubmit={handleSubmit} className="mx-auto max-w-3xl">
          <div className="flex gap-2">
            <Button
              type="button"
              variant={isListening ? "default" : "outline"}
              size="icon"
              onClick={toggleListening}
              disabled={status === "in_progress" || !apiKey}
              className={isListening ? "animate-pulse" : ""}
            >
              {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={apiKey ? "Type your message or use voice..." : "Configure API key first..."}
              disabled={status === "in_progress" || !apiKey}
              className="flex-1 bg-background"
            />
            <Button type="submit" disabled={status === "in_progress" || !inputValue.trim() || !apiKey} size="icon">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </form>
      </div>

      <ApiKeyDialog open={showSettings} onOpenChange={setShowSettings} onSave={handleSaveApiKey} currentKey={apiKey} />
    </div>
  )
}
